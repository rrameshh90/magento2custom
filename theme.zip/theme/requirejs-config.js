var config = {
    map: {
        '*': {
            slick:'js/slick/slick',
        }
    }
};
  
